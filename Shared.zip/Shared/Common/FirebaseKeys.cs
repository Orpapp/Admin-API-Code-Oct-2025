﻿namespace Shared.Common
{
    public class FirebaseKeys
    {
        public static string? FCMServerKey { get; set; }
        public static string? FCMSenderId { get; set; }
        public static string? FCMServerKeyFilePath { get; set; }
        public static string? FCMProjectId { get; set; }
        public static string? FirebaseMessagingUrl { get; set; }
    }
}
