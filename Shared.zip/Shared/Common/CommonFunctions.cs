﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel;
using System.Reflection;
//using static System.Net.Mime.MediaTypeNames;
using System.Drawing;
using System.Drawing.Drawing2D;
using SkiaSharp;
//using SixLabors.ImageSharp.PixelFormats;
//using SixLabors.ImageSharp;
//using SixLabors.ImageSharp.Processing;


namespace Shared.Common
{
    public class CommonFunctions
    {
        public static DateTime GetCurrentDateTime()
        {
            return DateTime.Now;    
        }
        public static string GetDescription(Enum value)
        {
            var enumMember = value.GetType().GetMember(value.ToString()).FirstOrDefault();
            var descriptionAttribute =
                enumMember == null
                    ? default
                    : enumMember.GetCustomAttribute(typeof(DescriptionAttribute)) as DescriptionAttribute;
            return
                descriptionAttribute == null
                    ? value.ToString()
                    : descriptionAttribute.Description;
        }

        public static List<string> SaveFile(List<IFormFile> files, string subDirectory, string imgPrefix = "")
        {
            List<string> tempFileAddress = new();
            subDirectory ??= string.Empty;
            var target = SiteKeys.SitePhysicalPath + "\\wwwroot" + subDirectory;

            Directory.CreateDirectory(target);

            files.ForEach(file =>
            {
                if (file.Length <= 0) return;

                var nFilename = string.Format(imgPrefix + "{0}{1}"
                //, Path.GetFileNameWithoutExtension(file.FileName)
                , Guid.NewGuid().ToString()
                // , Guid.NewGuid().ToString("N")
                , Path.GetExtension(file.FileName));
                var filePath = Path.Combine(target, nFilename);
                //tempFileAddress.Add(assetsUrl + subDirectory + "/" + nFilename);
                tempFileAddress.Add(nFilename);
                using var stream = new FileStream(filePath, FileMode.Create);
                file.CopyTo(stream);
            });
            return tempFileAddress;
        }


        public static string GetRelativeFilePath(string? fileName, string? folderPath)
        {
            string redirectUrl = string.Empty;
            if (!string.IsNullOrEmpty(fileName))
            {
                redirectUrl = string.Format("{0}{1}{2}", SiteKeys.SiteUrl, folderPath, fileName);
            }
            else
            {
                redirectUrl = string.Format("{0}{1}", SiteKeys.SiteUrl, SiteKeys.DefaultUserImage);
            }
            return redirectUrl;

        }

        public static string FormatDuration(int totalMinutes)
        {
            // Create a TimeSpan object from the total minutes
            TimeSpan timeSpan = TimeSpan.FromMinutes(totalMinutes);

            // Return formatted string as "hours:minutes"
            return $"{(int)timeSpan.TotalHours} h {timeSpan.Minutes} m";
        }



        public static SKBitmap GetReducedImage(int width, int height, Stream resourceImage)
        {
            using (var original = SKBitmap.Decode(resourceImage))
            {
                var resized = new SKBitmap(width, height);
                using (var canvas = new SKCanvas(resized))
                {
                    canvas.DrawBitmap(original, new SKRect(0, 0, width, height));
                }
                return resized;
            }
        }


        public static SKBitmap GetReducedCircleImage(int width, int height, Stream resourceImage)
        {
            // Decode the original image from the stream
            using (var original = SKBitmap.Decode(resourceImage))
            {
                // Create a new bitmap with the desired dimensions
                var resized = new SKBitmap(width, height);

                // Create a canvas to draw on the new bitmap
                using (var canvas = new SKCanvas(resized))
                {
                    // Calculate the center and radius of the circle
                    float radius = Math.Min(width, height) / 2.0f;
                    float centerX = width / 2.0f;
                    float centerY = height / 2.0f;

                    // Create a circular path
                    var path = new SKPath();
                    path.AddCircle(centerX, centerY, radius);

                    // Clip the canvas to the circular path
                    canvas.ClipPath(path, SKClipOperation.Intersect, true);

                    // Draw the original bitmap resized to fit within the new dimensions
                    canvas.DrawBitmap(original, new SKRect(0, 0, width, height));

                    // Set up the paint object for the circular border
                    var borderPaint = new SKPaint
                    {
                        IsAntialias = true,
                        Style = SKPaintStyle.Stroke,
                        Color = SKColors.Transparent,
                        StrokeWidth = 1
                    };

                    // Draw the circular border
                    canvas.DrawCircle(centerX, centerY, radius, borderPaint);
                }

                // Return the resized circular image
                return resized;
            }
        }

    }
}