﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.Reflection;

namespace Shared.Common
{
    public static class EnumExtensions
    {
        public static List<SelectListItem> ConvertEnumToListWithValuesAndDescriptions<TEnum>() where TEnum : Enum
        {
            var enumList = new List<SelectListItem>();
            var enumType = typeof(TEnum);

            foreach (var enumValue in Enum.GetValues(enumType))
            {
                FieldInfo? fieldInfo = enumType.GetField(enumValue.ToString() ?? string.Empty);

                // Check for Description attribute
                if (fieldInfo != null)
                {
                    var descriptionAttribute = fieldInfo.GetCustomAttribute<DescriptionAttribute>();
                    enumList.Add(new SelectListItem
                    {
                        Value = Convert.ToString((int)enumValue),
                        Text = descriptionAttribute?.Description
                    });
                }

            }

            return enumList;
        }


        //public static string ToDescription(this Enum value)        //    try
        //    {
        //        var attributes = (DescriptionAttribute[])value.GetType().GetField(value.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), false);
        //        return attributes.Length > 0 ? attributes[0].Description : value.ToString();
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}


        //public static T GetEnumValue<T>(string str) where T : struct, IConvertible
        //{
        //    if (!typeof(T).IsEnum)
        //    {
        //        throw new Exception("T must be an Enumeration type.");
        //    }
        //    T val = ((T[])Enum.GetValues(typeof(T)))[0];
        //    if (!string.IsNullOrEmpty(str))
        //    {
        //        foreach (T enumValue in (T[])Enum.GetValues(typeof(T)))
        //        {
        //            if (enumValue.ToString().ToUpper().Equals((Regex.Replace(str, " ", "")).ToUpper()))
        //            {
        //                val = enumValue;
        //                break;
        //            }
        //        }
        //    }

        //    return val;
        //}

        //public static string GetEnumDescription(Enum value)
        //{
        //    FieldInfo fi = value.GetType().GetField(value.ToString());

        //    DescriptionAttribute[] attributes =
        //        (DescriptionAttribute[])fi.GetCustomAttributes(
        //        typeof(DescriptionAttribute),
        //        false);

        //    if (attributes != null &&
        //        attributes.Length > 0)
        //    {
        //        return attributes[0].Description;
        //    }
        //    else
        //    {
        //        return value.ToString();
        //    }
        //}

        //public static T GetEnumValueFromDescription<T>(string description)
        //{
        //    Type enumType = typeof(T);
        //    if (!enumType.IsEnum)
        //    {
        //        throw new ArgumentException("T must be an enumerated type");
        //    }

        //    foreach (FieldInfo field in enumType.GetFields())
        //    {
        //        if (Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) is DescriptionAttribute attribute)
        //        {
        //            if (attribute.Description == description)
        //            {
        //                return (T)field.GetValue(null);
        //            }
        //        }
        //        else
        //        {
        //            if (field.Name == description)
        //            {
        //                return (T)field.GetValue(null);
        //            }
        //        }
        //    }

        //    throw new ArgumentException($"Enum value with description '{description}' not found");
        //}
    }
}
