﻿using Microsoft.AspNetCore.Http;
using Shared.Model.Request.Account;

namespace Shared.Common
{
    public static class SessionModel
    {
        private static HttpContext HttpContext => new HttpContextAccessor().HttpContext;
        public static UserDetailSessionModel? UserDetailSession
        {
            get
            {
                var data = HttpContext.Session.GetComplexData<UserDetailSessionModel>("UserDetailSession") == null ? null : HttpContext.Session.GetComplexData<UserDetailSessionModel>("UserDetailSession");
                return data;
            }
            set
            {
                HttpContext.Session.SetComplexData("UserDetailSession", value);
            }
        }

    }

}
