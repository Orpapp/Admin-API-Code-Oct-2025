﻿// Ignore Spelling: App

namespace Shared.Common
{
    public class SiteKeys
    {
        public static int UtcOffsetInSecond { get; set; }
        public static string? DeviceToken { get; set; }
        public static string? SitePhysicalPath { get; set; }
        public static string? SiteUrl { get; set; }
        public static string? UTCOffset { get; set; }
        public static int UtcOffsetInSecond_API { get; set; }
        public static string? FCMServerKey { get; set; }
        public static string? FCMSenderId { get; set; }



        public static string? IOSInAppSandboxURL { get; set; }
        public static string? IOSInAppSharedSecret { get; set; }
        public static string? IOSInAppProductionURL { get; set; }


        public static string? AndroidInAppAccountEmail { get; set; }
        public static string? AndroidInAppPackage { get; set; }
        public static string? AndroidInAppCertificatePath { get; set; }
        public static string? AndroidInAppGoogleApisURL { get; set; }
        public static string? AndroidInAppCertificatePassword { get; set; }
        public static string? AndroidInAppApplicationName { get; set; } 


        #region Application Statics 
        public const int DefultPageNumber = 1;
        public const int DefultPageSize = 10;
        public const string DefaultUserImage = "assets/images/DefaultImage.png";
        public const string DefaultLevelImage = "assets/images/DefaultLevelImage.png";
        public const string DefaultBackgroundImage = "assets/images/Background-Image.jpg";
        public const string DefaultSmallUserImage = "assets/images/DefaultSmallUserImage.png";
        public const string UserThumbImage = "Uploads/UserImagesThumb/";
        public const string UserImageFolderPath = "Uploads/UserImages/";
        public const string UserImagePhysical = "wwwroot\\Uploads\\UserImages\\";
        public const string UserImageThumb = "wwwroot\\Uploads\\UserImagesThumb\\";
        public const string LevelBackgroundImage = "\\wwwroot\\Uploads\\LevelBackground\\";
        public const string GetLevelBackgroundImage = "Uploads/LevelBackground/";
        

        public const string DefaultUserPng = "DefaultImage.png";
        public const string EmailTempaltePath = "wwwroot\\EmailTemplate";
        public const string AppName = "Orp";
        public const string StoppageImage = "assets/images/";
        public const string ItemsImage  = "Uploads/ItemsImage/";
        public const int LastDbLevel = 5;
        public const int EndLevel = 25;

        public const string VoucherImageFolderPath = "Uploads/VoucherImages/";
        public const string VoucherImagePhysical = "wwwroot\\Uploads\\VoucherImages\\";
        public const string DefaultVoucherImage = "assets/images/DefaultVoucherImage.png";

        #endregion
    }
}
