﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Text;

namespace Shared.Common
{
    public static class SessionExtensions
    {
        public static T? GetComplexData<T>(this ISession session, string key)
        {
            var data = session.GetString(key);
            if (data == null)
            {
                return default(T);
            }
            return JsonConvert.DeserializeObject<T>(data);
        }

        public static void SetComplexData(this ISession session, string key, object? value)
        {
            session.SetString(key, value == null ? null : JsonConvert.SerializeObject(value));
        }
    }

    //public  class SessionCommon
    //{
    //    public IHttpContextAccessor? httpContextAccessor;
    //    public static DateTime GetTimeSubtractOffSet(DateTime dt) // convert local time into UTC time
    //    {
    //        return dt.AddSeconds(GetOffsetSecond_FromKey() * -1);
    //    }
    //    public static DateTime GetTimeAfterAddOffSet(DateTime dt) // convert UTC into local time
    //    {
    //        return dt.AddSeconds(GetOffsetSecond_FromKey());
    //    }


    //    public static Int32 GetOffsetSecond_FromKey()
    //    {
    //        Int32 timeOffSet = 0;
    //        if (SiteKeys.UtcOffsetInSecond != 0)
    //        {
    //            timeOffSet = SiteKeys.UtcOffsetInSecond;
    //        }
    //        else
    //        {
    //            if (httpContextAccessor == null)
    //            {
    //                httpContextAccessor = new HttpContextAccessor();

    //                timeOffSet = httpContextAccessor.HttpContext.Session.GetComplexData<Int32>("UtcOffsetInSecond");
    //            }
    //            else
    //            {
    //                timeOffSet = httpContextAccessor.HttpContext.Session.GetComplexData<Int32>("UtcOffsetInSecond");
    //            }
    //        }
    //        return timeOffSet;
    //    }
    //}
}
