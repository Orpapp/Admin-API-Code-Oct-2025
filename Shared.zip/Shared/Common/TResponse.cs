﻿namespace Shared.Common
{
    public class TResponse<T>
    {
        public string? ResponseMessage { get; set; }
        public T ResponsePacket { get; set; } = default!;
    }
}
