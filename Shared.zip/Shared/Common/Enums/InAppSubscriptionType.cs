﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Common.Enums
{
    public enum InAppSubscriptionType
    {
        [Description("Free-Banner Landscape")]
        Free = 1,
        [Description("Monthly")]
        Monthly = 2,
        [Description("Quarterly")]
        Quarterly = 3,
        [Description("Yearly")]
        Yearly = 4
    }
}
