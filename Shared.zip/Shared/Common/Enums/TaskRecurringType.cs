﻿
using System.ComponentModel;

namespace Shared.Common.Enums
{
    public enum TaskRecurringType
    {
        [Description("Every Day")]
        EveryDay = 1,
        [Description("Every Week")]
        EveryWeek = 2,
        [Description("Every Fortnight")]
        EveryFortnight = 3,
        [Description("Every Month")]
        EveryMonth = 4,
        [Description("Every WeekDays")]
        EveryWeekDays = 5,
        [Description("Every Weekend")]
        EveryWeekend = 6,
    }
}
