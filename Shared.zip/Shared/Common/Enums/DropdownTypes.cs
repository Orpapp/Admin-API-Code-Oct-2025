﻿using System.ComponentModel;

namespace Shared.Common.Enums
{
    public enum DropdownTypeEnum
    {
        [Description("Option 1")]
        Option1 = 1,
        [Description("Option 2")]
        Option2 = 2
    }

    public enum CheckboxOptionsEnum
    {
        [Description("Subject 1")]
        Subject1 = 1,
        [Description("Subjec 2")]
        Subject2 = 2,
        [Description("Subject 3")]
        Subject3 = 3,
        [Description("Subject 4")]
        Subject4 = 4
    }

   

    public enum AutoCompleteEnum
    {
        [Description("ASP.NET")]
        ASPNET = 1,
        [Description("Angular")]
        Angular = 2,
        [Description("React Native")]
        ReactNative = 3,
        [Description("Flutter")]
        Flutter = 4,
        [Description("Node.js")]
        NodeJs = 5
    }
    public enum MultiselectDropdownEnum
    {
        [Description("Devloper")]
        Devloper = 1,
        [Description("Team Lead")]
        TeamLead = 2,
        [Description("Manager")]
        Manager = 3,
        [Description("Business Analyst")]
        BusinessAnalyst = 4,
        [Description("Designer")]
        Designer = 5,
        [Description("Tech Lead")]
        TechLead = 6,
    }
}
