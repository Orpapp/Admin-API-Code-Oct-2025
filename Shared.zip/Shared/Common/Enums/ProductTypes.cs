﻿using System.ComponentModel;

namespace Shared.Common.Enums
{
    public enum ProductTypes
    {
        [Description("Purchase")]
        Purchase = 1,
        [Description("Subscription")]
        Subscription = 2
    }
   
}
