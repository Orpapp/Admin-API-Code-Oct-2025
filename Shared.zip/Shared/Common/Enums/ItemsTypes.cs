﻿using System.ComponentModel;

namespace Shared.Common.Enums
{
    public enum ItemsTypes
    {
        [Description("Puzzle")]
        Puzzle = 1,
        [Description("Stickers")]
        Stickers = 2
    }
   
}
