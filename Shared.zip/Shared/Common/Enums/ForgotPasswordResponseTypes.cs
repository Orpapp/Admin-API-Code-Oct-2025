﻿namespace Shared.Common.Enums
{
    public enum ForgotPasswordResponseTypes
    {
        TokenUpdatedFailure = 0,
        TokenUpdatedSuccess = 1,
        ForgotEmailAlreadySent = 2,
    }
}
