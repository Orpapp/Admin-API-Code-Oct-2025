﻿using System.ComponentModel;

namespace Shared.Common.Enums
{
    public enum UserTypes
    {
        [Description("Admin")]
        Admin = 1,
        [Description("User")]
        User = 2
    }
    public enum DeviceTypeEnum
    {
        [Description("Android")]
        Android = 1,

        [Description("IOS")]
        IOS = 2,

        [Description("Web")]
        Web = 3,
    }
}
