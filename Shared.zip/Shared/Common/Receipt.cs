﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Shared.Common
{
    public class Receipt
    {
        #region Constructor
#nullable disable
        /// <summary>
        /// Creates the receipt from Apple's Response
        /// </summary>
        /// <param name="receipt"></param>
        public Receipt(string receipt)
        {

            JObject json = JObject.Parse(receipt);



            int status = -1;
            int.TryParse(json["status"].ToString(), out status);
            this.Status = status;
             
            //Status Codes and There meanings
            //Status 0 - Active Subscription, 21006 - Subscription Expired, 21007 - Receipt is from the Test Environment

            if (json["status"].ToString() == "0")
            {

                dynamic objData = JsonConvert.DeserializeObject(json["receipt"]?.ToString() ?? "");
                if (objData is not null)
                {
                    var objInAPP = JsonConvert.DeserializeObject(objData["in_app"]?.ToString() ?? "");
                    var objInAPPLast = (JsonConvert.DeserializeObject(objData["in_app"].ToString())).Last;

                    this.OriginalTransactionId = objInAPPLast != null ? objInAPPLast["original_transaction_id"].ToString() : "";
                    this.ProductId = objInAPPLast != null ? objInAPPLast["product_id"].ToString().Replace("\"", string.Empty) : "";
                    this.TransactionId = objInAPPLast != null ? objInAPPLast["transaction_id"].ToString().Replace("\"", string.Empty) : "";
                    var originalPurchaseDateMillis = objInAPPLast != null ? objInAPPLast["original_purchase_date_ms"].ToString() : "";

                    double ticks = Convert.ToDouble(originalPurchaseDateMillis) ?? 0;
                    TimeSpan time = TimeSpan.FromMilliseconds(ticks);
                    DateTime dtPurchase = new DateTime(1970, 1, 1) + time;
                    this.OriginalPurchaseDate = dtPurchase;
                    this.PurchaseDate = dtPurchase;
                }
                else
                {
                    //apple has changed the format of response, instead of last object we will have to use obj itself to fetch the data.
                    objData = JsonConvert.DeserializeObject(json["latest_receipt_info"].ToString());


                    dynamic pendingRenewalObj = JsonConvert.DeserializeObject(json["pending_renewal_info"].ToString());


                    IDictionary<DateTime, object> dates = new Dictionary<DateTime, object>();

                    if (objData != null)
                    {
                        foreach (dynamic item in objData)
                        {
                            if (item.ContainsKey("expires_date_ms"))
                            {
                                long ms = item["expires_date_ms"];
                                DateTime fd = (new DateTime(1970, 1, 1)).AddMilliseconds(Convert.ToDouble(ms));
                                if (!dates.ContainsKey(fd))
                                {
                                    dates.Add(fd, item);
                                }
                            }
                        }
                        if (dates.Count > 0)
                        {
                            var result = dates.OrderByDescending(p => p.Key).FirstOrDefault();
                            this.expires_date = result.Key;
                            objData = result.Value;
                        }
                    }

                    /*
                     * Get Subscription Cancel Status
                     * Added By Dinesh Yadav
                     * Date:24 Nov 2023
                     */
                    var cancellStatus = "0";
                    if (pendingRenewalObj != null)
                    {
                        foreach (dynamic item in pendingRenewalObj)
                        {
                            cancellStatus = item["auto_renew_status"].ToString();
                        }
                        this.AutoRenew = cancellStatus == "1" ? true : false;
                    }

                    this.OriginalTransactionId = objData["original_transaction_id"].ToString();
                    this.ProductId = objData["product_id"].ToString().Replace("\"", string.Empty);

                    DateTime purchaseDate = DateTime.MinValue;
                    if (DateTime.TryParseExact(objData["purchase_date"].ToString().Replace(" Etc/GMT", string.Empty).Replace("\"", string.Empty).Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out purchaseDate))
                        this.PurchaseDate = purchaseDate;

                    DateTime originalPurchaseDate = DateTime.MinValue;
                    if (DateTime.TryParseExact(objData["original_purchase_date"].ToString().Replace(" Etc/GMT", string.Empty).Replace("\"", string.Empty).Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out originalPurchaseDate))
                        this.OriginalPurchaseDate = originalPurchaseDate;
                    DateTime expires_date = DateTime.MinValue;
                    if (DateTime.TryParseExact(objData["expires_date"].ToString().Replace(" Etc/GMT", string.Empty).Replace("\"", string.Empty).Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out expires_date))
                        this.expires_date = expires_date;

                    this.TransactionId = objData["transaction_id"].ToString().Replace("\"", string.Empty);
                    this.Is_Trial_Period = objData["is_trial_period"].ToString() == "true" ? true : false;
                }
            }
        }

        #endregion Constructor

        #region Properties

        public string OriginalTransactionId
        {
            get;
            set;
        }

        public string Bvrs
        {
            get;
            set;
        }

        public string ProductId
        {
            get;
            set;
        }

        public DateTime? PurchaseDate
        {
            get;
            set;
        }

        public string BundleIdentifier
        {
            get;
            set;
        }

        public DateTime? OriginalPurchaseDate
        {
            get;
            set;
        }

        public DateTime? expires_date
        {
            get;
            set;
        }

        public string TransactionId
        {
            get;
            set;
        }

        public int Status
        {
            get;
            set;
        }

        public bool IsCancel
        {
            get;
            set;
        }

        public bool AutoRenew
        {
            get;
            set;
        }

        public bool Is_Trial_Period
        {
            get;
            set;
        }

        #endregion Properties
    }
}