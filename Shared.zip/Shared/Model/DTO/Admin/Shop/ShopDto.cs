﻿
using System.ComponentModel.DataAnnotations;

namespace Shared.Model.DTO.Admin.Shop
{
    public class ShopDto
    {
        public int Id { get; set; }
        #nullable disable
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Point Type")]
        public byte PointType { get; set; }
        [Display(Name = "Points")]
        public int Points { get; set; }
        [Display(Name = "Purchase Date")]
        public string PurchaseDate { get; set; }

        public int TotalRecord { get; set; }
        public DateTime AddedOnUTC { get; set; }
    }
}
