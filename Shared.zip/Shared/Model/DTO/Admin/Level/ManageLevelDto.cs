﻿using Shared.Model.Response;
using System.ComponentModel.DataAnnotations;

namespace Shared.Model.DTO.Admin.Level
{
    public class ManageLevelDto
    {
        [Display(Name = "S.No.")]
        public int Id { get; set; }
        [Display(Name = "Level Number")]
        public int LevelNumber { get; set; }
        [Display(Name = "Number Of Stoppage")]
        public int NumberOfStoppage { get; set; }
        [Display(Name = "Total Points")]
        public int TotalPoints { get; set; }
        public int TotalRecord { get; set; }
    }
}