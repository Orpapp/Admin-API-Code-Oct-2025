﻿
using System.ComponentModel.DataAnnotations;

namespace Shared.Model.DTO.Admin.Category
{
    public class CategoryDto
    {
        public int Id { get; set; }
         #nullable disable
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }
        public int  TotalRecord { get; set; }
        
    }
}

