﻿
using System.ComponentModel.DataAnnotations;

namespace Shared.Model.DTO.Admin.UserSubscription
{
    public class UserSubscriptionDto
    {
        public int Id { get; set; }
        #nullable disable
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Subscription Type")]
        public byte SubscriptionType { get; set; }
        [Display(Name = "Price")]
        public decimal Price { get; set; }
        [Display(Name = "Purchase Date")]
        public string PurchaseDate { get; set; }
        [Display(Name = "Expiry Date")]
        public string ExpiryDate { get; set; }
        [Display(Name = "Is Active")]
        public string IsActive { get; set; }
        public int TotalRecord { get; set; }
        public DateTime PurchaseOn { get; set; }
        public DateTime ExpiryOn { get; set; }
    }
}
