﻿using Shared.Model.Base;

namespace Shared.Model.DTO.Account
{
    public class UserLoginDetailDto : BaseModel
    {
        public long UserId { get; set; }
        public string? Email { get; set; }
        public string? PasswordHash { get; set; }
        public int UserType { get; set; }
        public string? Name { get; set; }
        public bool IsEmailVerified { get; set; }
    }
}
