﻿namespace Shared.Model.DTO.Account
{
    public class ApiLoginDto
    {
        public long UserId { get; set; }
        public string? Name { get; set; }
        public string? UserName { get; set; }
        public string? Email { get; set; }
        public string? ProfileImage { get; set; }
        public string? AuthorizationToken { get; set; }
        public string? AccessToken { get; set; }
        public int UserType { get; set; }
    }
}
