﻿namespace Shared.Model.DTO.Account
{
    public class CustomDto
    {
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
