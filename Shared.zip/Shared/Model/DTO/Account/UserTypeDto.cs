﻿namespace Shared.Model.DTO.Account
{
    public class UserTypeDto
    {
        public long UserId { get; set; }
        public int UserType { get; set; }
    }
}
