﻿using System.ComponentModel.DataAnnotations;

namespace Shared.Model.DTO.Account
{
    public class UserListDto
    {
        public long Id { get; set; }

        [Display(Name = "Name")]
        public string? Name { get; set; }

        [Display(Name = "Email")]
        public string? Email { get; set; }

        [Display(Name = "Phone Number")]
        public string? PhoneNumber { get; set; }
        public int TotalRecord { get; set; }

        [Display(Name = "Register Date")]
        public string? RegisterDate { get; set; }

        [Display(Name = "Action")]
        public string? Action { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }

        [Display(Name = "Is Deleted")]
        public bool IsDeleted { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
