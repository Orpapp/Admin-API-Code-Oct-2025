﻿using Shared.Model.Response;

namespace Shared.Model.DTO
{
    public class TaskDto
    {
        public int Id { get; set; } 
        public int CategoryId { get; set; }
        public string? SubCategoryName { get; set; }
        public string? SubCategoryQuotes { get; set; }
        public string? SubCategoryImage { get; set; }
        public List<SubTaskDto>? SubTask { get; set; }
    }
}
