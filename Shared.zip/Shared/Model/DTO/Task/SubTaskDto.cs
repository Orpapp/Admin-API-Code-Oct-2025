﻿namespace Shared.Model.DTO
{
    public class SubTaskDto
    {
        public int Id { get; set; } 
        public int TaskId { get; set; }
        public int DeficultyLevel { get; set; }
        public bool IsExecuted { get; set; }
        public string? Name { get; set; }
        public int Duration { get; set; }
      

    }
 
}
