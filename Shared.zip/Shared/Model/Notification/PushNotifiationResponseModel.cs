﻿namespace Shared.Model.Notification
{
    public class PushNotifiationResponseModel
    {
        public bool Status { get; set; }
        public string? Message { get; set; }
    }
}
