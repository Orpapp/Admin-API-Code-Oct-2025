﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class ProgressResponse : ProgressInfo
    {

        public TaskCompleted? TaskCompleted { get; set; }
        public TimeSpend? TimeSpend { get; set; }
        public List<ProgressTaskList> ProgressTaskLists { get; set; } = [];
    }

    public class ProgressInfo
    {
        public string? JoinedDate { get; set; }
        public int? TotalWeeks { get; set; }
    }


    public class TaskCompleted
    {
        public int? CreatedForToday { get; set; }
        public int? TodayCompleted { get; set; }
        public int? TotalTask { get; set; }
        public int? TotalCompletedTask { get; set; }

    }

    public class TimeSpend
    {
        public string? TotalHourTaskCreated { get; set; }
        public List<CategoryList>? Categories { get; set; }

    }
    public class CategoryList
    {
        public string? CatgoryName { get; set; }
        public int? TotalHourSubTaskCreated { get; set; }
        public string? Color { get; set; }
    }
    public class ProgressTaskList
    {
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Color { get; set; }
        public int? TotalTasks { get; set; }
        public int? CompletedTasks { get; set; }
        public int? CompletedPercentage { get; set; }
    }

}
