﻿ 

namespace Shared.Model.Response
{
    public class UserSubscriptionResponse
    {
        public int Id { get; set; } 
        public byte SubscriptionType { get; set; }
        public int InAppSubscriptionProductId { get; set; }
        #nullable disable
        public DateTime? PurchaseDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsCancelled { get; set; }
    }
}
