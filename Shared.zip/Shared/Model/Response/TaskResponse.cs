﻿
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Shared.Model.Response
{
   

    public class TaskResponse
    {
         #nullable disable
        public string Name { get; set; }
        public string StartTime { get; set; }
        public required string StartDate { get; set; }
        public required string TaskStartDate { get; set; }
        [JsonIgnore]
        public DateTime StartDateUTC { get; set; }
        [JsonIgnore]
        [Display(Name = "EndDateTime")]
        public DateTime EndDateUTC { get; set; }
        public string EndDate { get; set; }
        public string TaskEndDate { get; set; }
        public string Type { get; set; }
        [JsonIgnore]
        public int CreatedBy { get; set; }
        public int Duration { get; set; }
        public int Reminder { get; set; }
        public int Priority { get; set; }
        public int CategoryId { get; set; }
          #nullable enable
        public int? Id { get; set; }
        public string? Notes { get; set; }
        public string? CategoryName { get; set; }
        public string? Color { get; set; }
        [JsonIgnore]
        public int Offset { get; set; } 
        public int IsCompleted { get; set; }
        public bool IsScheduled { get; set; }
        public bool IsAnyTime { get; set; }
        public int RecurringType { get; set; }
        public List<SubTaskResponse>? SubTask { get; set; }

    }

    public class ReceivedTaskResponse
    {
#nullable disable
        public string Name { get; set; }
        public string StartTime { get; set; }
        public required string StartDate { get; set; }
        public required string TaskStartDate { get; set; }
        [JsonIgnore]
        public DateTime StartDateUTC { get; set; }
        [JsonIgnore]
        [Display(Name = "EndDateTime")]
        public DateTime EndDateUTC { get; set; }
        public string EndDate { get; set; }
        public string TaskEndDate { get; set; }
        public string Type { get; set; }
        [JsonIgnore]
        public int CreatedBy { get; set; }
        public int Duration { get; set; }
        public int Reminder { get; set; }
        public int Priority { get; set; }
        public int CategoryId { get; set; }
#nullable enable
        public int? Id { get; set; }
        public string? Notes { get; set; }
        public string? CategoryName { get; set; }
        public string? Color { get; set; }
        [JsonIgnore]
        public int Offset { get; set; }
        public int IsCompleted { get; set; }
        public bool IsScheduled { get; set; }
        public bool IsAnyTime { get; set; }
        public string? FriendName { get; set; }
        public string? FriendUserName { get; set; }
        public string? FriendProfileImage { get; set; }
        public int RecurringType { get; set; }  
        public List<SubTaskResponse>? SubTask { get; set; }

    }


    public class CompleteAndIncompleteTaskList
    {
        public List<TaskResponse>? PendingTaskList { get; set; } 
        public List<TaskResponse>? CompletedTaskList { get; set; }

    }
   
}
