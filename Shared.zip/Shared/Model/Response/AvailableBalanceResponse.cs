﻿ 

namespace Shared.Model.Response
{
    public class AvailableBalanceResponse
    {
        public int TotalStars { get; set; }
        public int TotalGreenPieces { get; set; }
        public int TotalSkyPieces { get; set; }
        public int TotalPurplePieces { get; set; }
        public int TotalYellowPieces { get; set; }
    }
}
