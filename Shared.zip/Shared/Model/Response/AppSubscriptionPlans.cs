﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class AppSubscriptionPlans
    {
#nullable disable
        public int Id { get; set; }
        public string Price { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string LimitedFeaturesTitle { get; set; }
        public string LimitedFeaturesDescription { get; set; }
        public string Note { get; set; }
        public string ProductId { get; set; } = null;
        public short ProductType { get; set; }
    }


    public class AppSubscriptionPlansResponse
    {
        public int Id { get; set; }
        public string Price { get; set; }
        public string Title { get; set; }
        public List<string> Description { get; set; }
        public string LimitedFeaturesTitle { get; set; }
        public List<string> LimitedFeaturesDescription { get; set; }
        public string Note { get; set; }
        public string ProductId { get; set; } = null;
        public short ProductType { get; set; } 
    }
}
