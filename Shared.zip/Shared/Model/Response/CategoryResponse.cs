﻿namespace Shared.Model.Response
{

    public class CategoryResponse
    {
        #nullable disable
        public int Id { get; set; } 
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string Color { get; set; }
    } 
}
