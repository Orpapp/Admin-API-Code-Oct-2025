﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class GetStopageListResponse
    {
        public int Id { get; set; }
        public string? StoppageImage { get; set; }
        public string? StoppageImage2 { get; set; }
        public int Points { get; set; }
        public int LevelId { get; set; }
    }
}
