﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class UserWeeklySummaryReport
    {
        public DateTime WeekStart { get; set; }
        public DateTime WeekEnd { get; set; }
        public string? CategoryName { get; set; }
        public string? Duration { get; set; }
        public float CompletedDurationPercentage { get; set; }
        public int TotalCompletedTaskCount { get; set; }
    }

    public class WeeklySummaryResponse
    {
        public DateTime WeekStart { get; set; }
        public DateTime WeekEnd { get; set; }
        public string? TotalDuration { get; set; } 
        public int TotalCompletedTaskCount { get; set; }
        public string? WeekNumber { get; set; }
        public List<CategorySummary> Categories { get; set; } = new List<CategorySummary>();
    }

    public class CategorySummary
    {
        public string? CategoryName { get; set; }
        public string? Duration { get; set; }  
        public float CompletedDurationPercentage { get; set; }
    }
}
