﻿
using System.Text.Json.Serialization;
namespace Shared.Model.Response
{

    public class SubTaskResponse
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public int DifficultyLevel { get; set; }
        public bool? IsCompleted { get; set; } = false;
        public string? Name { get; set; }
        public int Duration { get; set; }
        [JsonIgnore]
        public string? ScheduledDate { get; set; }

    }
}
