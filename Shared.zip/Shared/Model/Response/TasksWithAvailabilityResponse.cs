﻿ 
using System.Text.Json.Serialization; 

namespace Shared.Model.Response
{
    public class TasksWithAvailabilityResponse
    {
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? StartDateTime { get; set; }
        public string? EndDateTime { get; set; }
        public int Duration { get; set; }
        public int IsCompleted { get; set; }
        public bool IsAnyTime { get; set; }
        public int CreatedBy { get; set; }
        public string? CategoryName { get; set; }
        public string? Color { get; set; }
        public int CategoryId { get; set; }
        public string? Notes { get; set; }
        [JsonIgnore]
        public int Offset { get; set; }
        public bool IsAvailable { get; set; }

    }
}
