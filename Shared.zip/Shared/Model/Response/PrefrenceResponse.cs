﻿

namespace Shared.Model.Response
{
    using System;
    using System.Collections.Generic;
    using System.Text.Json.Serialization;

    public class Item
    {
#nullable disable
        public string Name { get; set; }
        public int Id { get; set; }
        public bool IsSelected { get; set; }
        public int Type { get; set; }

        [JsonIgnore]
        public bool IsDefault { get; set; }
    }

    public class PreferenceModel
    {
        public List<Item> Interest { get; set; }
        public List<Item> Motivate { get; set; }
        public List<Item> Difficult { get; set; }
    }


    public class VoucherImages
    {
        public string Image { get; set; }
    }


}
