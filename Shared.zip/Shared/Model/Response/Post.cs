﻿using System.Text.Json.Serialization;

namespace Shared.Model.Response
{

    public class Post
    {
        public int UserId { get; set; }
        public int Id { get; set; }
#nullable disable
        public string UserName { get; set; }
        public string ProfileImage { get; set; }
        public string CreatedOn { get; set; }
        public string Title { get; set; }
        public int Likes { get; set; }
        public int Comments { get; set; }
        public bool IsLike { get; set; }
        public List<PostImages> PostImages { get; set; }
    }

    public class PostImages
    {
        [JsonIgnore]
        public int PostId { get; set; }
        public string Attachment { get; set; }
    }
}
