﻿namespace Shared.Model.Response
{

    public class Friends
    {
#nullable disable
        public string Name { get; set; }
        public string ProfileImage { get; set; }
        public string UserName { get; set; }
        public string SendedOn { get; set; }
        public int UserId { get; set; } = 0;
        public int IsRequested { get; set; }
    }


    public class GroupsDetails
    {
        public int Id { get; set; }
        public int CreatedBy { get; set; }
        public string Title { get; set; }
        public string Attachment { get; set; }
        public string Description { get; set; }
    }
}
