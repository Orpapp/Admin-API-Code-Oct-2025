﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class GetUserLevelResponse
    {
        public int TotalPoints { get; set; }
        public string? UserThumbImage { get; set; }
        public string? BackgroundImage { get; set; }
        public int TodayEarnedPoint { get; set; }
        public int TodayPoint { get; set; }
        public int? Star {  get; set; }
        public int? Fire {  get; set; }
    }

    public class GetUserRewardResponse
    {
        public string? Type { get; set; }
        public string? Image {  get; set; }
        public int? NumberOfPuzzles { get; set; }
    }
}
