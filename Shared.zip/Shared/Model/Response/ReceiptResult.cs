﻿
namespace Shared.Model.Response
{
    public class ReceiptResult
    {
        /// <summary>
        /// Gets or sets the original purchase date.
        /// </summary>
        /// <value>
        /// The original purchase date.
        /// </value>
        public DateTime OriginalPurchaseDate { get; set; }

        /// <summary>
        /// Gets or sets the expiry date.
        /// </summary>
        /// <value>
        /// The expiry date.
        /// </value>
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public string? ProductId { get; set; }

        /// <summary>
        /// Gets or sets the transaction identifier.
        /// </summary>
        /// <value>
        /// The transaction identifier.
        /// </value>
        public string? TransactionId { get; set; }

        public int? CancelReason { get; set; }
        public bool AutoRenew { get; set; }
        public bool IsTrial { get; set;}
         
    }
}