﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class LevelInfo
    {
#nullable disable
        public int Id { get; set; }
        public int LevelId { get; set; }
        public int PreviewsLevelTotalPoint { get; set; } = 0;
        public int TotalPoints { get; set; }
        public int TotalStoppage { get; set; }
        [Required(ErrorMessage ="Points is required")]
        public int Points { get; set; }
        public string StoppageType { get; set; }
        public string StoppageImage { get; set; }
        
    }
}
