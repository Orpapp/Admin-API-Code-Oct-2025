﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Response
{
    public class ShopItemResponse
    {
        public string? Name { get; set; }
        public List<ShopCategoryItem> Items { get; set; } = [];
    }

    public class ShopCategoryItem
    {
        public int Id { get; set; }
        public byte ItemType { get; set; }
        public string? Name { get; set; }
        public int Stars { get; set; }
        public string? ImagePath { get; set; }
        public int GreenPieces { get; set; }
        public int SkyPieces { get; set; }
        public int PurplePieces { get; set; }
        public int YellowPieces { get; set; }
        public int IsOpen { get; set; }
    }
}
