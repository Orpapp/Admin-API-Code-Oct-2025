﻿
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Shared.Model.Response
{
   

    public class Reminder
    {
         #nullable disable
        public string Name { get; set; }
        public int Duration { get; set; }
        public int Priority { get; set; }
          #nullable enable
        public string DeviceToken { get; set; } = "";
        public int MsgId { get; set; } = 0;
        

    }

    public class TaskReminder
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string DeviceToken { get; set; } = "";
        public int Reminder { get; set; } 
        public DateTime StartDate { get; set; }
    }
   
}
