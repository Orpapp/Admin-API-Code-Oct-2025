﻿using System.Text.Json.Serialization;

namespace Shared.Model.Response
{

    public class Comments
    {
       
      
#nullable disable
        public List<AllComments> AllComments { get; set; }
       
        public int Count { get; set; }
       
    }

    public class AllComments
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string CreatedOn { get; set; }
#nullable disable
        public string UserName { get; set; }
        public string ProfileImage { get; set; }
       
        public string Message { get; set; }
    }

   
}
