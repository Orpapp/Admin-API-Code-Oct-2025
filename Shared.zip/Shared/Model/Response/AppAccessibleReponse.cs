﻿ 

namespace Shared.Model.Response
{
    public class AppAccessibleReponse
    {
        public bool IsAccessAllowed { get; set; }
        public string? PurchaseReceipt { get; set; }
        public byte ProductType { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public int? CancelReason { get; set; }
        public string? Message { get; set; }
    }
}
