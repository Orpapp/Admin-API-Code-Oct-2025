﻿namespace Shared.Model.Response
{
    public class ShopProductResponse
    {
        public int? Id { get; set; }
        public string? ProductId { get; set; }
        public string ? ProductName { get; set; }
        public byte ProductType { get; set; }
        public double Price { get; set; }
        public int NumberOfStars { get; set; }
        public int BonusStars { get; set; }
        public int BonusGreenPieces { get; set; }
        public int BonusSkyPieces { get; set; }
        public int BonusPurplePieces { get; set; }
        public int BonusYellowPieces { get; set; }
    }
}
