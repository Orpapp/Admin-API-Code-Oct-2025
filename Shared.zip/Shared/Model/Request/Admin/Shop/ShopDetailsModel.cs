﻿using Shared.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Request.Admin.Shop
{
    public class ShopDetailsModel : DataTableRequestModel
    {
        public ShopDetailsModel(DataTableParameters param) : base(param)
        {

        }
    }
}
