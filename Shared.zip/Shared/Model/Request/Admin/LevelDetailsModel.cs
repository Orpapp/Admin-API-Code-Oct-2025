﻿using Shared.Common;
using System.Security.Cryptography.X509Certificates;

namespace Shared.Model.Request.Admin
{
    public class LevelDetailsModel : DataTableRequestModel
    {
        
        public LevelDetailsModel(DataTableParameters param) : base(param)
        {
           
        }
    }
}

