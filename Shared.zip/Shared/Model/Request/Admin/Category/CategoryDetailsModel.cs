﻿using Shared.Common;
using System.Security.Cryptography.X509Certificates;

namespace Shared.Model.Request.Admin.Category
{
    public class CategoryDetailsModel : DataTableRequestModel
    {
        
        public CategoryDetailsModel(DataTableParameters param) : base(param)
        {
           
        }
    }
}

