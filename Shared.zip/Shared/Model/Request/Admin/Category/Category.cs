﻿

using Shared.Resources;
using System.ComponentModel.DataAnnotations;

namespace Shared.Model.Request.Admin.Category
{
    public class Category
    {
        public int Id { get; set; }
#nullable disable
        [Required(ErrorMessageResourceType = typeof(ResourceString), ErrorMessageResourceName = "NameRequired", ErrorMessage = null)]
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string Color { get; set; }

    }


   

}

