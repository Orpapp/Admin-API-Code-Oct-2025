﻿using Shared.Common; 

namespace Shared.Model.Request.Admin.UserSubscription
{
    public class UserSubscriptionDetailsModel : DataTableRequestModel
    {
        public byte ProductType { get; set; }
        public UserSubscriptionDetailsModel(DataTableParameters param) : base(param)
        {

        }
    }
}
