﻿namespace Shared.Model.Request.Admin
{
    public class AddFormRequestModel
    {
        public int? NumericValue { get; set; }
        public decimal? DecimalValue { get; set; }
        public string? TextValue { get; set; }
        public int? DropdownValue { get; set; }
        //public int MultiSelectValue { get; set; }
        public bool RadioButtonValue { get; set; }
        public bool CheckBoxValue1 { get; set; }
        public bool CheckBoxValue2 { get; set; }
        public string? DatePickerValue { get; set; }
        public string? TimePickerValue { get; set; }
        public string? StartDate { get; set; }
        public string? EndDate { get; set; }
        public string? StartTime { get; set; }
        public string? EndTime { get; set; }
        public string? AutoCompleteValue { get; set; }
        public List<string> SelectedSubjects { get; set; } = new();
        public List<string> SubjectsList { get; set; } = new();
        public List<string> SelectedProfile { get; set; } = new();
    }
}
