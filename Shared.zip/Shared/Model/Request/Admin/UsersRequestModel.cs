﻿using Shared.Common;

namespace Shared.Model.Request.Admin
{
    public class UsersRequestModel : DataTableRequestModel
    {
       

        public UsersRequestModel(DataTableParameters param) : base(param)
        {

        }
    }
}
