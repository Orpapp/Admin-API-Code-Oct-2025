﻿ 
namespace Shared.Model.Request.Items
{
    public class ShopItems
    {
        public int Id { get; set; }
        public byte ItemType { get; set; }
        public string? Name { get; set; }
        public string? Category { get; set; }
        public int Stars { get; set; }
        public string? ImagePath { get; set; }
        public int DisplayOrder { get; set; }
        public int GreenPieces { get; set; }
        public int SkyPieces { get; set; }
        public int PurplePieces { get; set; }
        public int YellowPieces { get; set; }
        public int IsOpen { get; set; }
    }
}
