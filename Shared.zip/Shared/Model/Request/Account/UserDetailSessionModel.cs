﻿namespace Shared.Model.Request.Account
{
    public class UserDetailSessionModel
    {
        public long UserId { get; set; }
        public string? EmailId { get; set; }
        public string? Name { get; set; }
        public int UserTypeId { get; set; }
        public string? ProfileImage { get; set; }
    }
}
