﻿namespace Shared.Model.Request.Account
{
    public class TokenRequest
    {
        public string Token { get; set; } = string.Empty;
    }

    public class EmailRequest
    {
        public string Email { get; set; } = string.Empty;
    }
}
