﻿
using System.Text.Json.Serialization;

namespace Shared.Model.Request.Account
{

    public class PrefenceRequest
    {
#nullable disable
        public string Name { get; set; }
        public int Type { get; set; }
        public int Id { get; set; }


    }

    public class PreferenceSearchRequest
    {
#nullable disable
        public string Keyword { get; set; }
        public int Type { get; set; }
       


    }
}
