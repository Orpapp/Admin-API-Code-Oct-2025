﻿using Microsoft.AspNetCore.Http;
using System.Text.Json.Serialization;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Shared.Model.Request.Account
{
    public class Profile
    {
#nullable disable
        [JsonIgnore]
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string UserName { get; set; }
        public int Gender { get; set; }
        public string Dob { get; set; }
        public string Country { get; set; }
        public string MotivationQuote { get; set; }
        public string CoverPicture { get; set; }
        public string ProfileImage { get; set; }
        public int Streak { get; set; }
        public int TotalStars { get; set; }
    }
    public class ImageUrl
    {
        public string Url { get; set; } = string.Empty;

    }
    public class ImageFile
    {
#nullable enable
        public IFormFile? File { get; set; } = null;

    }

    public class ProfileDetails
    {
#nullable disable
        [JsonIgnore]
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string UserName { get; set; }
        public int Gender { get; set; }
        public string Dob { get; set; }
        public string Country { get; set; }
        public string MotivationQuote { get; set; }
        public string CoverPicture { get; set; }
        public string ProfileImage { get; set; }
        public int TotalLikes { get; set; }
        public int TotalCompletedTasks { get; set; }
        public int TotalStars { get; set; }
        public int Streak { get; set; }
        public int TotalGreenPieces { get; set; }
        public int TotalSkyPieces { get; set; }
        public int TotalPurplePieces { get; set; }
        public int TotalYellowPieces { get; set; }
    }

    public class ProfileDetailsResponse
    {
        public ProfileDetails Profile { get; set; }
        public List<UserFriend> Friends { get; set; }
        public List<UserInterests> Interests { get; set; }
        public List<UserStickers> Stickers { get; set; }
        public int FriendCount { get; set; }
    }

    public class UserFriend
    {
        public string ProfileImage { get; set; }
    }

    public class UserInterests
    {
        public string Name { get; set; }
    }

    public class UserStickers
    {
        public string Name { get; set; }
        public string ImagePath { get; set; }
        public int TotalStickers { get; set; }
    }

    public class UserStreak
    {
        public int Streak { get; set; }
        public int TotalStars { get; set; }
    }
}
