﻿using Shared.Model.DTO.Account;

namespace Shared.Model.Request.Account
{
    public class LoginResponseModel
    {
        public bool Succeeded { get; set; }
        public List<string>? Errors { get; }
        public string? Message { get; set; }
        public UserLoginDetailDto? ObjUser { get; set; }
    }
}
