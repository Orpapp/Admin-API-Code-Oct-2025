﻿using Shared.Common.Enums;
using System.ComponentModel.DataAnnotations;

namespace Shared.Model.Request.Account
{
    public class ApiLoginRequest
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string DeviceToken { get; set; } = string.Empty;
        public short DeviceType { get; set; }
    }

    public class SocialLoginRequest
    {
        public string SocialId { get; set; } = string.Empty;
        public string SocialType { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string DeviceToken { get; set; } = string.Empty;
        public short DeviceType { get; set; }
    }
}
