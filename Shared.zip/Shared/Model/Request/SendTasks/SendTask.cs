﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Request.SendTasks
{
    public class SendTask
    {
        public int ReceiverId { get; set; }
        public int TaskId { get; set; }
    }
    
    public class AcceptTask
    {
        public int TaskId { get; set; }
    }
}
