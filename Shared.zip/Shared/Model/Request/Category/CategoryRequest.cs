﻿namespace Shared.Model.Request.Category
{ 
    public class CategoryRequest
    {
       public int TaskId { get; set; }
    }

}
