﻿
using System.Text.Json.Serialization;

namespace Shared.Model.Request.Task
{
   
    public class SubTask
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public int DifficultyLevel { get; set; }
        [JsonIgnore]
        public bool? IsCompleted { get; set; } = false;
        public string? Name { get; set; }
        public int Duration { get; set; } 

    }

    public class SubTaskId
    {
        public int Id { get; set; }
    }
}
