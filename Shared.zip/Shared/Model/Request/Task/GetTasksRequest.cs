﻿

using System.Text.Json.Serialization;

namespace Shared.Model.Request.Task
{
    public class GetTasksRequest
    {
#nullable disable
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }

    public class RequestId
    {
#nullable disable
        public int Id { get; set; }
    }
    public class GetTasksWithAvailabilityRequest
    {
#nullable disable
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}
