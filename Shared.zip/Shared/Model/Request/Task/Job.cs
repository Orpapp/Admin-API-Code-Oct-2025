﻿

using System.Text.Json.Serialization;

namespace Shared.Model.Request.Task
{
    public class Job
    {

        public string? StartTime { get; set; }
#nullable disable
        public string Name { get; set; } 
      
        public required string StartDate { get; set; }
        [JsonIgnore]
        public  DateTime StartDateUTC { get; set; }
        [JsonIgnore]
        public  DateTime EndDateUTC { get; set; }
        public string EndDate { get; set; }
        public string Type { get; set; }
        [JsonIgnore]
        public int CreatedBy { get; set; }
        public int Duration { get; set; }
        public int Reminder { get; set; }
        public int Priority { get; set; }
        public int CategoryId { get; set; }
        #nullable enable
        public int? Id { get; set; }
        public string? Notes { get; set; }
        [JsonIgnore]
        public int  Offset { get; set;}

        [JsonIgnore]
        public bool IsAnyTime { get; set; }
        public byte? RecurringType { get; set; }
        public string? SelectedWeekDays { get; set; }
        public string? SelectedMonthDays { get; set; }
        public bool NeedsToSendTask { get; set; }
    }

    public class TaskId
    {
        public int Id { get; set; }
        public string ScheduledDate { get; set; } = "";
        public bool IsDeleteFuture { get; set; }
    }
    public class ResponsewithId
    {
        #nullable disable
        public bool Data { get; set; }
        public int Id { get; set; }
    }
}
