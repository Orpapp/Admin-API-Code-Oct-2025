﻿

using System.Text.Json.Serialization;
namespace Shared.Model.Request.Task
{
   

    public class TaskRequest
    {
         #nullable disable
        public string Name { get; set; }
        public string StartTime { get; set; }
        public required string StartDate { get; set; }
        [JsonIgnore]
        public DateTime StartDateUTC { get; set; }
        [JsonIgnore]
        public DateTime EndDateUTC { get; set; }
        public string EndDate { get; set; }
        [JsonIgnore]
        public DateTime? UpdateFromDateUTC { get; set; }
        public string UpdateFromDate { get; set; }
        public string Type { get; set; }
        [JsonIgnore]
        public int CreatedBy { get; set; }
        public int Duration { get; set; }
        public int Reminder { get; set; }
        public int Priority { get; set; }
        public int CategoryId { get; set; }
          #nullable enable
        public int? Id { get; set; }
        public string? Notes { get; set; }
        [JsonIgnore]
        public int Offset { get; set; }
        public List<SubTask>? SubTask { get; set; }

    }
   
}
