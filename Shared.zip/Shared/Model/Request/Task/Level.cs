﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Request.Task
{
    public class Level
    {
        public int Id { get; set; }
        public int LevelNumber { get; set; }
        public int NumberOfStoppage { get; set; }
        public int TotalPoints { get; set; }
    }
}
