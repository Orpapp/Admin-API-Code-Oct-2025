﻿using System.Text.Json.Serialization;
namespace Shared.Model.Request.Social
{

    public class Reward
    {
#nullable disable
        public int Id { get; set; }
        [JsonIgnore]
        public int UserId { get; set; }
        public int Points { get; set; }
        public int Food { get; set; }
        public int Power { get; set; }
        public int Time { get; set; }

    }

    public class SpendTime
    {
        public int Id { get; set; }
        [JsonIgnore]
        public int SpendedTime { get; set; }
        public string Time { get; set; }
    }
}
