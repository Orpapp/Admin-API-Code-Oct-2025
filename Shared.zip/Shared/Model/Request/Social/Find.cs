﻿

using System.Text.Json.Serialization;

namespace Shared.Model.Request.Social
{
    public class Find
    {
#nullable disable
        public string SearchTerm { get; set; }
        public int PageNumber { get; set; }
       
        public bool FindFriend { get; set; }
        [JsonIgnore]
        public int Sender { get; set; }
    }

    public class SendRequest
    {
        public int Receiver { get; set; }
        [JsonIgnore]
        public int Sender { get; set; }
    }

    public class RequestAction
    {
        public int SenderId { get; set; }
        [JsonIgnore]
        public int ReceiverId { get; set; }
        public bool IsAccept { get; set; } 
    }
    public class GetRequest
    {
        [JsonIgnore]
        public int Id { get; set; }
        public int @PageNumber { get; set; }
    }
  
}
