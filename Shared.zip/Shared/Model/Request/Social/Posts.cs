﻿using System.ComponentModel;
using System.Text.Json.Serialization;

namespace Shared.Model.Request.Social
{

    public class Posts
    {

#nullable disable

        public int GroupId { get; set; }
        [JsonIgnore]
        public int CreatedBy { get; set; }
        public string Title { get; set; }
        public List<Images> PostImages { get; set; }

    }

    public class Images
    {
        public string ImageName { get; set; }
    }
    
    public class Like
    {
        public bool IsLike { get; set; }
        public int PostId { get; set; }
        [JsonIgnore]
        public int LikedBy { get; set; }
    }
    public class Comment
    {
        public string Message { get; set; }
        public int PostId { get; set; }
        [JsonIgnore]
        public int CommentedBy { get; set; }
    }

    public class PostId
    {
        public int Id { get; set; }
    }

    public class GetComments
    {
        public int PageNumber { get; set; }
        public int Id { get; set; }
    }
}
