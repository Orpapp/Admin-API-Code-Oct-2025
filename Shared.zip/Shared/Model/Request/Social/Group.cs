﻿

using Shared.Model.Request.Task;
using System.Text.Json.Serialization;

namespace Shared.Model.Request.Social
{

    public class Group
    {
        
#nullable disable
        public int Id { get; set; }
        public int CreatedBy { get; set; }
        public string Title { get; set; }
        public string Attachment { get; set; }
        public string Description { get; set; }
        public List<Participants> ParticipantsId { get; set; }                                                                                                                                                                                                                                                                                                                                             
    }

    public class GroupPosts
    {
        public int GroupId { get; set; }
        public int PageNumber { get; set; }
        [JsonIgnore]
        public int Id { get; set; }
    }

    public class GetGroups
    {
        public string SearchTerm { get; set; }
        public int PageNumber { get; set; }
        [JsonIgnore]
        public int Id { get; set; }
    }
#nullable enable
    public class Participants
    {
        public int Id { get; set; }
    }
    
    public class GroupId
    {
        public int Id { get; set; }
    }

    public class ParticipantsDetails
    {
        public int UserId { get; set; }
        //public int Id { get; set; }
#nullable disable
        public string UserName { get; set; }
        public string ProfileImage { get; set; }
        public string Name { get; set; }
    }

}
