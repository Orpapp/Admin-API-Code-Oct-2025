﻿
using Shared.Model.Response;
using System.Text.Json.Serialization;

namespace Shared.Model.Request.UserSubscription
{
    public class UserSubscription
    {
        #nullable disable
        public int Id { get; set; }
        [JsonIgnore]
        public int UserId { get; set; }
        public byte ProductType { get; set; }
        public int? SubscriptionProductId { get; set; } = null;
        public int? InAppSubscriptionProductId { get; set; } = null;

        public string PriceWithCurrencySymbol { get; set; }
        public string ProductId { get; set; }
        public double Price { get; set; }
        public string Receipt { get; set; }
        [JsonIgnore]
        public string TransactionId { get; set; }
        [JsonIgnore]
        public DateTime? PurchaseDate { get; set; }
        [JsonIgnore]
        public DateTime? ExpiryDate { get; set; }
        [JsonIgnore]
        public bool IsActive { get; set; } 
        public byte DeviceType { get; set; }
        [JsonIgnore]
        public string SharedSecret { get; set; } 
        public int PlanMonth { get; set; } 
    }

    public class UserSubscriptionDetails
    {
#nullable disable
        public int Id { get; set; }
        [JsonIgnore]
        public int UserId { get; set; }
        public byte ProductType { get; set; }
        public int? SubscriptionProductId { get; set; } = null;
        public int? InAppSubscriptionProductId { get; set; } = null;


        public string ProductId { get; set; }
        public string Price { get; set; }
        public string PriceWithCurrencySymbol { get; set; }
        public string Receipt { get; set; }
        [JsonIgnore]
        public string TransactionId { get; set; }
        [JsonIgnore]
        public DateTime? PurchaseDate { get; set; }
        [JsonIgnore]
        public DateTime? ExpiryDate { get; set; }
        [JsonIgnore]
        public bool IsActive { get; set; }
        public byte DeviceType { get; set; }
        [JsonIgnore]
        public string SharedSecret { get; set; }
        public int PlanMonth { get; set; }

        public string Title { get; set; }
        public List<string> Description { get; set; }
        public List<string> LimitedFeaturesDescription { get; set; }
        [JsonIgnore]
        public string Desc { get; set; }
        public string LimitedFeaturesTitle { get; set; }
        [JsonIgnore]
        public string LimitedFeaturesDesc { get; set; }
        public string Note { get; set; }
    }
}
