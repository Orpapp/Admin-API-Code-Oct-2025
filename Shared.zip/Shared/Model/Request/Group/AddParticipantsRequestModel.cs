﻿using Shared.Model.Request.Social;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Request.Group
{
    public class AddParticipantsRequestModel
    {
        public int GroupId { get; set; }
        public List<Participants> ParticipantsId { get; set; } = new List<Participants>();
    }
}
