﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Request.Group
{
    public class DeleteGroupParticipantRequestModel
    {
        public int GroupId { get; set; }
        public int ParticipantId { get; set;}
    }
}
