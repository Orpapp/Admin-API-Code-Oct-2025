﻿
using System.Text.Json.Serialization;

namespace Shared.Model.Request.Shop
{
    public class Shop
    {  
        public int Id { get; set; }  
        public int Quantity { get; set; }
    }
}
