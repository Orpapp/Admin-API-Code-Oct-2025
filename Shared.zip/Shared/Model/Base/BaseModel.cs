﻿using System.ComponentModel.DataAnnotations;

namespace Shared.Model.Base
{
    public abstract class BaseModel
    {
        public BaseModel()
        {
            this.CreatedDate = DateTime.UtcNow;
            this.ModifiedDate = DateTime.UtcNow;
            this.IsDeleted = false;
            this.IsActive = true;
        }
        [Key]
        public long UserDetailId { get; set; }
        private DateTime? _createDate;
        public DateTime? CreatedDate
        {
            get
            {
                if (_createDate == null || _createDate == DateTime.MinValue)
                {
                    _createDate = DateTime.UtcNow;
                }
                return _createDate.Value;
            }
            set { _createDate = value; }
        }
        private DateTime? _modificationDate;
        public DateTime? ModifiedDate
        {
            get
            {
                if (_modificationDate == null || _modificationDate == DateTime.MinValue)
                {
                    _modificationDate = DateTime.UtcNow;
                }
                return _modificationDate.Value;
            }
            set { _modificationDate = value; }
        }

        private bool? _isActive;
        public bool IsActive
        {
            get
            {
                return _isActive ?? true;
            }
            set
            {
                _isActive = value;
            }
        }

        private bool? _isDeleted;
        public bool IsDeleted
        {
            get
            {
                return _isDeleted ?? false;
            }
            set
            {
                _isDeleted = value;
            }
        }
    }
}
