﻿using Shared.Model.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Model.Result
{
    public class GetUserProgressResult
    {
        public UserProgressInfo? UserProgressInfo { get; set; }
    }

    public class UserProgressInfo : ProgressInfo
    {
        public int? CreatedForToday { get; set; }
        public int? TodayCompleted { get; set; }
        public int? TotalTask { get; set; }
        public int? TotalHourTaskCreated { get; set; }
        public int? TotalCompletedTask { get; set; }
        public int? CreatedTaskByToday { get; set; }

    }
}
